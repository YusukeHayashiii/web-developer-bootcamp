// const subreddits = [
//   'cooking',
//   'books',
//   'chickens',
//   'life',
//   'pics',
//   'soccer',
//   'movies',
// ];

// for (let i = 0; i < subreddits.length; i++) {
//   console.log(`Visit reddit.com/r/${subreddits[i]}`);
// }

// for (let subreddit of subreddits) {
//   console.log(`Visit reddit.com/r/${subreddit}`);
// }

// const seatingChart = [
//   ['伊藤', '松本', '鈴木'],
//   ['井上', '田中', '河野', '吉田'],
//   ['安倍', '後藤', '橋本']
// ];

// for (let i = 0; i < seatingChart.length; i++) {
//   const row = seatingChart[i];
//   console.log(`${i + 1}行目`);
//   for (let j = 0; j < row.length; j++) {
//       console.log(row[j]);
//   }
// }

// for (let row of seatingChart) {
//   for (let student of row) {
//     console.log(student);
//   }
// }

for (let char of 'hello world') {
  console.log(char);
}